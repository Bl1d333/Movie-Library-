import pytest
import json
import os
from models import Movie, MovieLibrary

@pytest.fixture
def empty_library(tmp_path):
    file = tmp_path / "test.json"
    return MovieLibrary(filepath=str(file))

@pytest.fixture
def library_with_movies(empty_library):
    empty_library.add_movie("Интерстеллар", "Фантастика", "2014", "8.6")
    empty_library.add_movie("Начало", "Фантастика", "2010", "8.8")
    empty_library.add_movie("Побег из Шоушенка", "Драма", "1994", "9.1")
    return empty_library

# Позитивные тесты
class TestPositive:
    def test_add_valid_movie(self, empty_library):
        empty_library.add_movie("Матрица", "Фантастика", "1999", "8.7")
        assert len(empty_library.movies) == 1
        assert empty_library.movies[0].title == "Матрица"

    def test_add_movie_with_rating_float(self, empty_library):
        empty_library.add_movie("Тест", "Драма", "2000", "7.5")
        assert empty_library.movies[0].rating == 7.5

    def test_json_persistence(self, library_with_movies, tmp_path):
        assert os.path.exists(library_with_movies.filepath)
        new_lib = MovieLibrary(filepath=library_with_movies.filepath)
        assert len(new_lib.movies) == 3

    def test_filter_by_genre(self, library_with_movies):
        result = library_with_movies.filter_movies(genre="Фантастика")
        assert len(result) == 2

    def test_filter_by_year(self, library_with_movies):
        result = library_with_movies.filter_movies(year="1994")
        assert len(result) == 1
        assert result[0].title == "Побег из Шоушенка"

    def test_filter_combined(self, library_with_movies):
        result = library_with_movies.filter_movies(genre="Фантастика", year="2010")
        assert len(result) == 1
        assert result[0].title == "Начало"

    def test_delete_movie(self, library_with_movies):
        library_with_movies.delete_movie(0)
        assert len(library_with_movies.movies) == 2

# Негативные тесты
class TestNegative:
    def test_empty_title(self, empty_library):
        with pytest.raises(ValueError, match="Название не может быть пустым"):
            empty_library.add_movie("", "Драма", "2000", "5")

    def test_empty_genre(self, empty_library):
        with pytest.raises(ValueError, match="Жанр не может быть пустым"):
            empty_library.add_movie("Фильм", "", "2000", "5")

    def test_year_not_int(self, empty_library):
        with pytest.raises(ValueError, match="Год должен быть целым числом"):
            empty_library.add_movie("Фильм", "Драма", "год2000", "5")

    def test_rating_out_of_range_high(self, empty_library):
        with pytest.raises(ValueError, match="Рейтинг должен быть от 0 до 10"):
            empty_library.add_movie("Фильм", "Драма", "2000", "11")

    def test_rating_out_of_range_low(self, empty_library):
        with pytest.raises(ValueError, match="Рейтинг должен быть от 0 до 10"):
            empty_library.add_movie("Фильм", "Драма", "2000", "-0.1")

    def test_rating_not_number(self, empty_library):
        with pytest.raises(ValueError, match="Рейтинг должен быть числом"):
            empty_library.add_movie("Фильм", "Драма", "2000", "хорошо")

# Граничные тесты
class TestBoundary:
    def test_rating_zero(self, empty_library):
        empty_library.add_movie("Фильм", "Драма", "2000", "0")
        assert empty_library.movies[0].rating == 0.0

    def test_rating_ten(self, empty_library):
        empty_library.add_movie("Фильм", "Драма", "2000", "10")
        assert empty_library.movies[0].rating == 10.0

    def test_earliest_year(self, empty_library):
        empty_library.add_movie("Первый фильм", "Экспериментальное", "1888", "5.0")
        assert empty_library.movies[0].year == 1888
